#include "ProductionWorker.h"


void ProductionWorker::setShift(int _shift)
{
	this->shift = _shift; 
}

void ProductionWorker::setPayRate(double _payRate)
{
	this->payRate = _payRate;
}
