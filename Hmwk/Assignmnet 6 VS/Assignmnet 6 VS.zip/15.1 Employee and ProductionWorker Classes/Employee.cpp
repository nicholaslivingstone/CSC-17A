#include "Employee.h"

void Employee::setName(string _name)
{
	this->name = _name; 
}

void Employee::setNumber(unsigned int _number)
{	
	this->number = _number; 
}

void Employee::setHired(date _hired)
{
	this->hired = _hired;
}
