#pragma once
#include "GradedActivity.h"

class Essay : public GradedActivity
{
public:
	Essay(int, int, int, int);
};

